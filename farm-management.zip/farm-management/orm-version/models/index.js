const sequelize = require('../database');
const Field = require('./Field');
const Animal = require('./Animal');
const FieldAnimal = require('./FieldAnimal');

Field.belongsToMany(Animal, {
  through: FieldAnimal,
  foreignKey: 'field_id',
  otherKey: 'animal_id',
  as: 'animals'
});

Animal.belongsToMany(Field, {
  through: FieldAnimal,
  foreignKey: 'animal_id',
  otherKey: 'field_id',
  as: 'fields'
});

Field.hasMany(FieldAnimal, { foreignKey: 'field_id', as: 'fieldAssignments' });
Animal.hasMany(FieldAnimal, { foreignKey: 'animal_id', as: 'animalAssignments' });
FieldAnimal.belongsTo(Field, { foreignKey: 'field_id', as: 'field' });
FieldAnimal.belongsTo(Animal, { foreignKey: 'animal_id', as: 'animal' });

const syncDatabase = async () => {
  try {
    await sequelize.sync({ alter: true });
    console.log('Adatbázis szinkronizálva');
  } catch (error) {
    console.error('Hiba az adatbázis szinkronizálásakor:', error);
  }
};

syncDatabase();

module.exports = {
  sequelize,
  Field,
  Animal,
  FieldAnimal
};