const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Field = sequelize.define('Field', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  location: {
    type: DataTypes.STRING(255)
  },
  size: {
    type: DataTypes.DECIMAL(10, 2)
  },
  soil_type: {
    type: DataTypes.STRING(100)
  }
}, {
  tableName: 'fields',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = Field;