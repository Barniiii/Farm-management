const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const FieldAnimal = sequelize.define('FieldAnimal', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  field_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'fields',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  animal_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'animals',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  assigned_date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  notes: {
    type: DataTypes.TEXT
  }
}, {
  tableName: 'field_animals',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = FieldAnimal;