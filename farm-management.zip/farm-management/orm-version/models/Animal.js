const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Animal = sequelize.define('Animal', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  species: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  breed: {
    type: DataTypes.STRING(100)
  },
  birth_date: {
    type: DataTypes.DATEONLY
  },
  weight: {
    type: DataTypes.DECIMAL(10, 2)
  },
  health_status: {
    type: DataTypes.STRING(50)
  }
}, {
  tableName: 'animals',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = Animal;