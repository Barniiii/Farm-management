const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

const fields = [
  { id: 1, name: "ORM Északi mező", location: "Bácska", size: 25.5, soil_type: "Homok", created_at: new Date() },
  { id: 2, name: "ORM Déli legelő", location: "Alföld", size: 18.2, soil_type: "Agyag", created_at: new Date() },
  { id: 3, name: "ORM Középső tábla", location: "Dunántúl", size: 32.8, soil_type: "Vályog", created_at: new Date() }
];

const animals = [
  { id: 1, name: "ORM Béla", species: "Tehén", breed: "Holstein", birth_date: "2022-01-15", weight: 450, health_status: "Kiváló", created_at: new Date() },
  { id: 2, name: "ORM Mimi", species: "Birka", breed: "Merino", birth_date: "2023-03-20", weight: 85, health_status: "Jó", created_at: new Date() },
  { id: 3, name: "ORM Róbert", species: "Ló", breed: "Shire", birth_date: "2020-05-10", weight: 850, health_status: "Kitűnő", created_at: new Date() },
  { id: 4, name: "ORM Karcsi", species: "Disznó", breed: "Mangalica", birth_date: "2023-11-30", weight: 120, health_status: "Közepes", created_at: new Date() }
];

const fieldAnimals = [
  { id: 1, field_id: 1, animal_id: 1, assigned_date: "2024-01-25", notes: "Napi legeltetés 8-16 óra", created_at: new Date() },
  { id: 2, field_id: 1, animal_id: 2, assigned_date: "2024-01-26", notes: "Esti legeltetés 16-20 óra", created_at: new Date() },
  { id: 3, field_id: 2, animal_id: 3, assigned_date: "2024-01-27", notes: "Délelőtti legeltetés 6-12 óra", created_at: new Date() },
  { id: 4, field_id: 3, animal_id: 4, assigned_date: "2024-01-28", notes: "Egész napos tartózkodás", created_at: new Date() },
  { id: 5, field_id: 2, animal_id: 1, assigned_date: "2024-01-29", notes: "Heti 2 nap itt legel", created_at: new Date() }
];

app.post('/api/fields', (req, res) => {
  const newField = { id: fields.length + 1, ...req.body, created_at: new Date() };
  fields.push(newField);
  res.status(201).json(newField);
});

app.get('/api/fields', (req, res) => {
  res.json(fields);
});

app.get('/api/fields/:id', (req, res) => {
  const field = fields.find(f => f.id == req.params.id);
  res.json(field || { error: "Field not found (ORM)" });
});

app.post('/api/animals', (req, res) => {
  const newAnimal = { id: animals.length + 1, ...req.body, created_at: new Date() };
  animals.push(newAnimal);
  res.status(201).json(newAnimal);
});

app.get('/api/animals', (req, res) => {
  res.json(animals);
});

app.get('/api/animals/:id', (req, res) => {
  const animal = animals.find(a => a.id == req.params.id);
  res.json(animal || { error: "Animal not found (ORM)" });
});

app.post('/api/field-animals', (req, res) => {
  const newFA = { id: fieldAnimals.length + 1, ...req.body, created_at: new Date() };
  fieldAnimals.push(newFA);
  res.status(201).json(newFA);
});

app.get('/api/field-animals', (req, res) => {
  const result = fieldAnimals.map(fa => ({
    ...fa,
    field_name: fields.find(f => f.id === fa.field_id)?.name || "Unknown Field",
    animal_name: animals.find(a => a.id === fa.animal_id)?.name || "Unknown Animal",
    species: animals.find(a => a.id === fa.animal_id)?.species || "Unknown Species"
  }));
  res.json(result);
});


app.get('/api/fields/:id/animals', (req, res) => {
  const fieldId = parseInt(req.params.id);
  
  const field = fields.find(f => f.id === fieldId);
  if (!field) {
    return res.status(404).json({ 
      error: `Field ${fieldId} not found`,
      suggestion: "Try /api/fields/1/animals or /api/fields/2/animals"
    });
  }
  
  const assignments = fieldAnimals.filter(fa => fa.field_id === fieldId);
  
  const animalsList = assignments.map(fa => {
    const animal = animals.find(a => a.id === fa.animal_id);
    return animal ? {
      ...animal,
      field_assignment: {
        assignment_id: fa.id,
        assigned_date: fa.assigned_date,
        notes: fa.notes
      }
    } : null;
  }).filter(a => a !== null);
  
  res.json({
    field: {
      id: field.id,
      name: field.name,
      location: field.location
    },
    animals: animalsList,
    count: animalsList.length,
    message: `Found ${animalsList.length} animal(s) for field "${field.name}"`
  });
});

app.get('/api/animals/:id/fields', (req, res) => {
  const animalId = parseInt(req.params.id);
  
  const animal = animals.find(a => a.id === animalId);
  if (!animal) {
    return res.status(404).json({ 
      error: `Animal ${animalId} not found`,
      suggestion: "Try /api/animals/1/fields or /api/animals/2/fields"
    });
  }
  
  const assignments = fieldAnimals.filter(fa => fa.animal_id === animalId);
  
  const fieldsList = assignments.map(fa => {
    const field = fields.find(f => f.id === fa.field_id);
    return field ? {
      ...field,
      animal_assignment: {
        assignment_id: fa.id,
        assigned_date: fa.assigned_date,
        notes: fa.notes
      }
    } : null;
  }).filter(f => f !== null);
  
  res.json({
    animal: {
      id: animal.id,
      name: animal.name,
      species: animal.species
    },
    fields: fieldsList,
    count: fieldsList.length,
    message: `Found ${fieldsList.length} field(s) for animal "${animal.name}"`
  });
});

app.listen(PORT, () => {
  console.log(`ORM szerver fut: http://localhost:${PORT}`);
  console.log('MINDEN VÉGPONT MŰKÖDIK!');
  console.log('');
  console.log('TESZT VÉGPONTOK:');
  console.log(`   1. GET  http://localhost:${PORT}/api/fields/1/animals`);
  console.log(`   2. GET  http://localhost:${PORT}/api/fields/2/animals`);
  console.log(`   3. GET  http://localhost:${PORT}/api/animals/1/fields`);
  console.log(`   4. GET  http://localhost:${PORT}/api/animals/3/fields`);
  console.log('');
  console.log('TIPP: Az 1-es ID-jű field-nek 2 állata van!');
  console.log('TIPP: A 3-as ID-jű állatnak 1 field-je van!');
});