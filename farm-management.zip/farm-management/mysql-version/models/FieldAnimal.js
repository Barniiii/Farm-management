const db = require('../database');

const FieldAnimal = {
  createTable: () => {
    console.log('✅ FieldAnimals tábla kész (demo)');
  },

  create: (fieldAnimal, callback) => {
    console.log('🔗 FieldAnimal létrehozva:', fieldAnimal);
    
    // DEMO: Mindig sikerüljön
    const mockResult = {
      insertId: Math.floor(Math.random() * 1000) + 1
    };
    
    setTimeout(() => {
      if (callback) callback(null, mockResult);
    }, 100);
  },

  findAll: (callback) => {
    // Teszt hozzárendelések
    const testData = [
      { 
        id: 1, 
        field_id: 1, 
        animal_id: 1,
        field_name: "Északi mező",
        animal_name: "Béla",
        species: "Tehén",
        assigned_date: "2024-01-25",
        notes: "Napi legeltetés",
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      },
      { 
        id: 2, 
        field_id: 1, 
        animal_id: 2,
        field_name: "Északi mező",
        animal_name: "Mimi",
        species: "Birka",
        assigned_date: "2024-01-26",
        notes: "Esti legeltetés",
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      }
    ];
    
    setTimeout(() => {
      if (callback) callback(null, testData);
    }, 100);
  },

  findById: (id, callback) => {
    const testData = [
      { 
        id: parseInt(id), 
        field_id: 1, 
        animal_id: 1,
        assigned_date: "2024-01-25",
        notes: "Teszt hozzárendelés #" + id,
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      }
    ];
    
    setTimeout(() => {
      if (callback) callback(null, testData);
    }, 100);
  },

  update: (id, fieldAnimal, callback) => {
    console.log('✏️  FieldAnimal frissítve:', id, fieldAnimal);
    
    setTimeout(() => {
      if (callback) callback(null, { affectedRows: 1 });
    }, 100);
  },

  delete: (id, callback) => {
    console.log('🗑️  FieldAnimal törölve:', id);
    
    setTimeout(() => {
      if (callback) callback(null, { affectedRows: 1 });
    }, 100);
  },

  findAnimalsByField: (fieldId, callback) => {
    console.log('🔍 Állatok field alapján:', fieldId);
    
    const testData = [
      { 
        id: 1, 
        name: "Béla", 
        species: "Tehén", 
        breed: "Holstein",
        assigned_date: "2024-01-25",
        notes: "Napi legeltetés"
      },
      { 
        id: 2, 
        name: "Mimi", 
        species: "Birka", 
        breed: "Merino",
        assigned_date: "2024-01-26",
        notes: "Esti legeltetés"
      }
    ];
    
    setTimeout(() => {
      if (callback) callback(null, testData);
    }, 100);
  },

  findFieldsByAnimal: (animalId, callback) => {
    console.log('🔍 Field-ok animal alapján:', animalId);
    
    const testData = [
      { 
        id: 1, 
        name: "Északi mező", 
        location: "Bácska",
        assigned_date: "2024-01-25",
        notes: "Napi legeltetés"
      },
      { 
        id: 2, 
        name: "Déli legelő", 
        location: "Alföld",
        assigned_date: "2024-01-24",
        notes: "Reggeli legeltetés"
      }
    ];
    
    setTimeout(() => {
      if (callback) callback(null, testData);
    }, 100);
  }
};

module.exports = FieldAnimal;