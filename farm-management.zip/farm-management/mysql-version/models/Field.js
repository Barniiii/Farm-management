const db = require('../database');

const Field = {
  createTable: () => {
    console.log('✅ Fields tábla (demo mód)');
  },

  create: (field, callback) => {
    console.log('Field létrehozva:', field);
    if (callback) callback(null, { insertId: 1 });
  },

  findAll: (callback) => {
    const testData = [
      { id: 1, name: "Északi mező", location: "Bácska", size: 25.5, soil_type: "Homok" },
      { id: 2, name: "Déli legelő", location: "Alföld", size: 18.2, soil_type: "Agyag" }
    ];
    if (callback) callback(null, testData);
  },

  findById: (id, callback) => {
    const testData = [
      { 
        id: parseInt(id), 
        name: "Mező #" + id, 
        location: "Magyarország", 
        size: 20.0 + parseInt(id), 
        soil_type: "Teszt",
        created_at: new Date().toISOString()
      }
    ];
    if (callback) callback(null, testData);
  },

  update: (id, field, callback) => {
    console.log('Field frissítve:', id, field);
    if (callback) callback(null, { affectedRows: 1 });
  },

  delete: (id, callback) => {
    console.log('Field törölve:', id);
    if (callback) callback(null, { affectedRows: 1 });
  }
};

module.exports = Field;