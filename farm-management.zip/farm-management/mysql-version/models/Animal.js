const db = require('../database');

const Animal = {
  createTable: () => {
    console.log('✅ Animals tábla kész (demo)');
  },

  create: (animal, callback) => {
    console.log('🐮 Animal létrehozva:', animal.name);
    
    // DEMO: Mindig sikerüljön
    const mockResult = {
      insertId: Math.floor(Math.random() * 100) + 1
    };
    
    // Kis késleltetés, mint egy valós adatbázis
    setTimeout(() => {
      if (callback) callback(null, mockResult);
    }, 100);
  },

  findAll: (callback) => {
    // Teszt adatok
    const testData = [
      { 
        id: 1, 
        name: "Béla", 
        species: "Tehén", 
        breed: "Holstein",
        birth_date: "2022-01-15",
        weight: 450.5,
        health_status: "Kiváló",
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      },
      { 
        id: 2, 
        name: "Mimi", 
        species: "Birka", 
        breed: "Merino",
        birth_date: "2023-03-20",
        weight: 85.2,
        health_status: "Jó",
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      }
    ];
    
    setTimeout(() => {
      if (callback) callback(null, testData);
    }, 100);
  },

  findById: (id, callback) => {
    // Mindig visszaad egy teszt állatot
    const testData = [
      { 
        id: parseInt(id), 
        name: "Állat #" + id, 
        species: id % 2 === 0 ? "Tehén" : "Birka",
        breed: "Teszt fajta",
        birth_date: "2023-01-01",
        weight: 100 + parseInt(id) * 50,
        health_status: "Jó",
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      }
    ];
    
    console.log('🔍 Animal lekérdezve ID:', id);
    setTimeout(() => {
      if (callback) callback(null, testData);
    }, 100);
  },

  update: (id, animal, callback) => {
    console.log('✏️  Animal frissítve:', id, animal);
    
    setTimeout(() => {
      if (callback) callback(null, { affectedRows: 1 });
    }, 100);
  },

  delete: (id, callback) => {
    console.log('🗑️  Animal törölve:', id);
    
    setTimeout(() => {
      if (callback) callback(null, { affectedRows: 1 });
    }, 100);
  }
};

module.exports = Animal;