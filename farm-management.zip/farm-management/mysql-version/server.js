const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Modellek importálása
const Field = require('./models/Field');
const Animal = require('./models/Animal');
const FieldAnimal = require('./models/FieldAnimal');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware-ek
app.use(cors());
app.use(express.json());

// Táblák létrehozása szerver indításakor
Field.createTable();
Animal.createTable();
FieldAnimal.createTable();

// ========== FIELDS CRUD végpontok ==========
// CREATE
app.post('/api/fields', (req, res) => {
  Field.create(req.body, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a földterület létrehozásakor' });
    }
    res.status(201).json({ id: result.insertId, ...req.body });
  });
});

// READ all
app.get('/api/fields', (req, res) => {
  Field.findAll((err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a földterületek lekérdezésekor' });
    }
    res.json(results);
  });
});

// READ one
app.get('/api/fields/:id', (req, res) => {
  Field.findById(req.params.id, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a földterület lekérdezésekor' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Földterület nem található' });
    }
    res.json(results[0]);
  });
});

// UPDATE
app.put('/api/fields/:id', (req, res) => {
  Field.update(req.params.id, req.body, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a földterület frissítésekor' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Földterület nem található' });
    }
    res.json({ message: 'Földterület sikeresen frissítve', id: req.params.id });
  });
});

// DELETE
app.delete('/api/fields/:id', (req, res) => {
  Field.delete(req.params.id, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a földterület törlésekor' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Földterület nem található' });
    }
    res.json({ message: 'Földterület sikeresen törölve', id: req.params.id });
  });
});

// ========== ANIMALS CRUD végpontok ==========
// CREATE
app.post('/api/animals', (req, res) => {
  Animal.create(req.body, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba az állat létrehozásakor' });
    }
    res.status(201).json({ id: result.insertId, ...req.body });
  });
});

// READ all
app.get('/api/animals', (req, res) => {
  Animal.findAll((err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba az állatok lekérdezésekor' });
    }
    res.json(results);
  });
});

// READ one
app.get('/api/animals/:id', (req, res) => {
  Animal.findById(req.params.id, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba az állat lekérdezésekor' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Állat nem található' });
    }
    res.json(results[0]);
  });
});

// UPDATE
app.put('/api/animals/:id', (req, res) => {
  Animal.update(req.params.id, req.body, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba az állat frissítésekor' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Állat nem található' });
    }
    res.json({ message: 'Állat sikeresen frissítve', id: req.params.id });
  });
});

// DELETE
app.delete('/api/animals/:id', (req, res) => {
  Animal.delete(req.params.id, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba az állat törlésekor' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Állat nem található' });
    }
    res.json({ message: 'Állat sikeresen törölve', id: req.params.id });
  });
});

// ========== FIELD_ANIMALS CRUD végpontok ==========
// CREATE (állat hozzárendelése földterülethez)
app.post('/api/field-animals', (req, res) => {
  FieldAnimal.create(req.body, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a hozzárendelés létrehozásakor' });
    }
    res.status(201).json({ id: result.insertId, ...req.body });
  });
});

// READ all hozzárendelések
app.get('/api/field-animals', (req, res) => {
  FieldAnimal.findAll((err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a hozzárendelések lekérdezésekor' });
    }
    res.json(results);
  });
});

// ========== SPECIÁLIS LEKÉRDEZÉSEK ==========
// Egy földterület összes állata
app.get('/api/fields/:id/animals', (req, res) => {
  FieldAnimal.findAnimalsByField(req.params.id, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba az állatok lekérdezésekor' });
    }
    res.json(results);
  });
});

// Egy állat földterület története
app.get('/api/animals/:id/fields', (req, res) => {
  FieldAnimal.findFieldsByAnimal(req.params.id, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Hiba a földterületek lekérdezésekor' });
    }
    res.json(results);
  });
});

// Szerver indítása
app.listen(PORT, () => {
  console.log(`🚀 Szerver fut a http://localhost:${PORT} címen`);
  console.log(`📝 Végpontok:`);
  console.log(`   POST   /api/fields`);
  console.log(`   GET    /api/fields`);
  console.log(`   GET    /api/fields/:id`);
  console.log(`   PUT    /api/fields/:id`);
  console.log(`   DELETE /api/fields/:id`);
  console.log(`   ... és ugyanezek /api/animals és /api/field-animals végpontokra`);
});